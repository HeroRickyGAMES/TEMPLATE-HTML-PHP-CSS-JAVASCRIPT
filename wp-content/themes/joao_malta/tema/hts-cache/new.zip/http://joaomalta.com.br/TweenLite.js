<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="pt-BR">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1">
	
	<title>Página não encontrada &laquo;  João Malta</title>
	<link rel="pingback" href="http://joaomalta.com.br/xmlrpc.php" />
	
	<link rel="icon" type="image/png" href="http://joaomalta.com.br/wp-content/uploads/2017/09/favicon.png">	
	<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css" rel="stylesheet">
	<link href="http://joaomalta.com.br/wp-content/themes/joao_malta/js/owl.carousel.2.0.0-beta.2.4/assets/owl.carousel.css" rel="stylesheet">
	
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js"></script>
	
	<link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600,700" rel="stylesheet">
	<link href="http://joaomalta.com.br/wp-content/themes/joao_malta/style.css?v=1624495724" type="text/css" rel="stylesheet">
	
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
		<link href="http://joaomalta.com.br/wp-content/themes/joao_malta/css/fontello-ie7.css" type="text/css" rel="stylesheet">
    <![endif]-->
	
	<script type="text/javascript">
	var template_url = "http://joaomalta.com.br/wp-content/themes/joao_malta";
	</script>
	
	<link rel='dns-prefetch' href='//s.w.org' />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/2.3\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/joaomalta.com.br\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.8.17"}};
			!function(t,a,e){var r,i,n,o=a.createElement("canvas"),l=o.getContext&&o.getContext("2d");function c(t){var e=a.createElement("script");e.src=t,e.defer=e.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(e)}for(n=Array("flag","emoji4"),e.supports={everything:!0,everythingExceptFlag:!0},i=0;i<n.length;i++)e.supports[n[i]]=function(t){var e,a=String.fromCharCode;if(!l||!l.fillText)return!1;switch(l.clearRect(0,0,o.width,o.height),l.textBaseline="top",l.font="600 32px Arial",t){case"flag":return(l.fillText(a(55356,56826,55356,56819),0,0),e=o.toDataURL(),l.clearRect(0,0,o.width,o.height),l.fillText(a(55356,56826,8203,55356,56819),0,0),e===o.toDataURL())?!1:(l.clearRect(0,0,o.width,o.height),l.fillText(a(55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447),0,0),e=o.toDataURL(),l.clearRect(0,0,o.width,o.height),l.fillText(a(55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447),0,0),e!==o.toDataURL());case"emoji4":return l.fillText(a(55358,56794,8205,9794,65039),0,0),e=o.toDataURL(),l.clearRect(0,0,o.width,o.height),l.fillText(a(55358,56794,8203,9794,65039),0,0),e!==o.toDataURL()}return!1}(n[i]),e.supports.everything=e.supports.everything&&e.supports[n[i]],"flag"!==n[i]&&(e.supports.everythingExceptFlag=e.supports.everythingExceptFlag&&e.supports[n[i]]);e.supports.everythingExceptFlag=e.supports.everythingExceptFlag&&!e.supports.flag,e.DOMReady=!1,e.readyCallback=function(){e.DOMReady=!0},e.supports.everything||(r=function(){e.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",r,!1),t.addEventListener("load",r,!1)):(t.attachEvent("onload",r),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&e.readyCallback()})),(r=e.source||{}).concatemoji?c(r.concatemoji):r.wpemoji&&r.twemoji&&(c(r.twemoji),c(r.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='contact-form-7-css'  href='http://joaomalta.com.br/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=4.9' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='http://joaomalta.com.br/wp-content/plugins/revslider/public/assets/css/settings.css?ver=5.1.6' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<link rel='stylesheet' id='wp-pagenavi-css'  href='http://joaomalta.com.br/wp-content/plugins/wp-pagenavi/pagenavi-css.css?ver=2.70' type='text/css' media='all' />
<script type='text/javascript' src='http://joaomalta.com.br/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://joaomalta.com.br/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://joaomalta.com.br/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.tools.min.js?ver=5.1.6'></script>
<script type='text/javascript' src='http://joaomalta.com.br/wp-content/plugins/revslider/public/assets/js/jquery.themepunch.revolution.min.js?ver=5.1.6'></script>
<link rel='https://api.w.org/' href='http://joaomalta.com.br/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://joaomalta.com.br/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://joaomalta.com.br/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.8.17" />
<meta name="generator" content="Powered by Slider Revolution 5.1.6 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<!-- BEGIN GADWP v5.1.2.5 Universal Analytics - https://deconf.com/google-analytics-dashboard-wordpress/ -->
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
  ga('create', 'UA-108232244-1', 'auto');
  ga('send', 'pageview');
</script>
<!-- END GADWP Universal Analytics -->
	
	</head>
<body class="error404">
		
	<div id="menu-mobile" class="overlay visible-xs hidden-sm hidden-md hidden-lg">
		<a href="javascript:void(0)" class="closebtn" onclick="$('#menu-mobile').css('left','100%');">
			MENU
			<span class="fa-stack fa-lg">
				<i class="fa fa-circle fa-stack-2x"></i>
				<i class="fa fa-times fa-stack-1x"></i>
			</span>
		</a>
		
		<div class="overlay-content"></div>
	</div>
	<section id="header-mobile" class="visible-xs hidden-sm hidden-md hidden-lg" data-spy="affix" data-offset-top="50">
		<div class="container">
			<div class="row">
				<div class="col-xs-6">
					<a href="http://joaomalta.com.br" title="João Malta">
						<img class="logo" src="http://joaomalta.com.br/wp-content/uploads/2017/09/logo_jm.png" alt="João Malta">
					</a>
				</div>
				<div class="col-xs-6 text-right">
					<button type="button" class="navbar-toggle" onclick="return AbreMenuMobile();">
						MENU
						<span class="fa-stack fa-lg">
							<i class="fa fa-circle fa-stack-2x"></i>
							<i class="fa fa-bars fa-stack-1x"></i>
						</span>
					</button>
				</div>
			</div>
		</div>
	</section>
	
	<section id="header" class="hidden-xs visible-sm visible-md visible-lg" data-spy="affix" data-offset-top="86">
		<div class="container">
			<div class="col-sm-3 text-sm-center col-md-3 text-md-left logo-base">
				<a href="http://joaomalta.com.br">
					<img class="logo" src="http://joaomalta.com.br/wp-content/uploads/2017/09/logo_jm.png" alt="João Malta">
				</a>
			</div>
			<div class="col-sm-9 col-md-9 text-center">
				<div class="menu-menu-principal-container"><ul id="menu-menu-principal" class="menu"><li id="menu-item-16" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-16"><a href="#header">HOME</a></li>
<li id="menu-item-17" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-17"><a href="#b2">SOBRE</a></li>
<li id="menu-item-18" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-18"><a href="#b4">CONSULTORIA</a></li>
<li id="menu-item-19" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-19"><a href="#b5">PLANOS</a></li>
<li id="menu-item-73" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-73"><a href="#b6">PERSONAL</a></li>
<li id="menu-item-20" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-20"><a href="#b7">CONTATO</a></li>
</ul></div>			</div>
					</div>
	</section>
	<section id="page-inner" class="p-erro">
		<div class="container text-center">
			<h1>404 - Não Encontrado</h1>
			<div class="clearfix"></div>
			<h2>A página que você estava procurando não foi encontrada</h2>
		</div>
	</section>
	
	<section id="footer" style="background-image:url(http://joaomalta.com.br/wp-content/uploads/2017/09/bg-rodape.png);">
		<div class="container">
			<div class="text-xs-center col-md-3 text-md-left col-lg-4">
				<img class="logo" src="http://joaomalta.com.br/wp-content/uploads/2017/09/logo_jm.png" alt="João Malta">
			</div>
			<div class="text-xs-center col-md-9 text-md-left col-lg-8">
				<p>Se tiver alguma dúvida, entre em contato!</p>
				<ul><li>(11) 9.7248-8891</li><li><a href="mailto:contato@joaomalta.com.br" target="_blank">contato@joaomalta.com.br</a></li><li>www.joaomalta.com.br</li></ul>
			</div>
		</div>
	</section>
	
	<script type="text/javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/jquery.matchHeight/0.7.2/jquery.matchHeight-min.js"></script>
	<script src="http://joaomalta.com.br/wp-content/themes/joao_malta/js/owl.carousel.2.0.0-beta.2.4/owl.carousel.min.js"></script>
	<script src="http://joaomalta.com.br/wp-content/themes/joao_malta/js/init.js?v=1.32221"></script>
	
	<!-- IE9 form fields placeholder fix -->
    <!--[if lt IE 9]>
    <script>contact_form_IE9_placeholder_fix();</script>
    <![endif]-->  
	
	<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/joaomalta.com.br\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"recaptcha":{"messages":{"empty":"Verifique se voc\u00ea n\u00e3o \u00e9 um rob\u00f4."}}};
/* ]]> */
</script>
<script type='text/javascript' src='http://joaomalta.com.br/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=4.9'></script>
<script type='text/javascript' src='http://joaomalta.com.br/wp-includes/js/wp-embed.min.js?ver=4.8.17'></script>
	
	  </body>
</html>